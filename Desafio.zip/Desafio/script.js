let produtos = [

    { nome: "Arroz 5kg", preco: 22.90, categoria: "Alimento", estoque: 10 },

    { nome: "Refrigerante 2L", preco: 8.50, categoria: "Bebida", estoque: 5 },

    { nome: "Sabonete", preco: 2.30, categoria: "Higiene", estoque: 20 }

];

function ListarProdutos() {
    for (var i = 0; i < produtos.length; i++) {
        alert(`
                Nome: ${produtos[i].nome}
                Preço: ${produtos[i].preco}
                Categoria: ${produtos[i].categoria}
                Estoque: ${produtos[i].estoque}`);
    }
    if (produtos == null) {
        alert('Lista vazia')
    }

}

function CadastrarProdutos() {

    let nomeProduto = prompt("Nome do produto: ");
    if (!nomeProduto) {
        alert("Insira pelo menos um Nome!")
        return
    }

    let precoProduto = prompt("Preço do produto: ");
    if (isNaN(precoProduto)) {
        alert("Insira um número maior do que zero!")
        return
    }

    let categoriaProduto = prompt("Categoria do produto (alimento, bebida, higiene): ");
    if (!categoriaProduto) {
        alert("Insira pelo menos uma Categoria!")
        return
    }
    else if (categoriaProduto != "alimento" && (categoriaProduto != "bebida") && (categoriaProduto != "higiene")) {
        alert("Insira uma categoria válida !!!")
        return
    }

    let estoqueProduto = prompt("Estoque do produto: ");
    if (isNaN(estoqueProduto)) {
        alert("Insira pelo menos um Estoque!")
        return
    }



    let novoproduto = {
        nome: nomeProduto,
        preco: precoProduto,
        categoria: categoriaProduto,
        estoque: estoqueProduto
    }

    produtos.push(novoproduto);

    alert(`PRODUTOS CADASTRADO COM SUCESSO!
       Nome: ${nomeProduto}
       Preço: ${precoProduto}
       Categoria: ${categoriaProduto}
       Estoque: ${estoqueProduto}un`)
}

function VerTotaisDoEstoque() {

    const count = produtos.length

    let somaEstoque = 0;
    let valorTotal = 0;

    for (let i = 0; i < count; i++) {
        somaEstoque = somaEstoque + produtos[i].estoque;
        valorTotal = valorTotal + (produtos[i].preco * produtos[i].estoque)
    }

    alert(
        "Total de produtos: " + count +
        "Soma das quantidades em estoque: \n" + somaEstoque +
        "Valor total do estoque: R$ \n" + valorTotal
    );

}

function FiltrarPorCategoria() {

    let categoriaEscolhida = prompt(
        "Escolha uma categoria entre as opções a seguir: (Alimento, Bebida, Higiene)"
    ).trim();



    switch (categoriaEscolhida) {
        case "Alimento":
        case "alimento":


            for (let i = 0; i < produtos.length; i++) {

                if (produtos[i].categoria == 'Alimento') {
                    alert(`Alimentos
                Nome: ${produtos[i].nome}
                Preço: ${produtos[i].preco}
                Categoria: ${produtos[i].categoria}
                Estoque: ${produtos[i].estoque}un`)

                }
            }
            break;
        case "Bebida":
        case "bebida":


            for (let i = 0; i < produtos.length; i++) {

                if (produtos[i].categoria == 'Bebida') {
                    alert(`Alimentos
                Nome: ${produtos[i].nome}
                Preço: ${produtos[i].preco}
                Categoria: ${produtos[i].categoria}
                Estoque: ${produtos[i].estoque}un`)

                }
            }
            break;
        case "Higiene":
        case "higiene":


            for (let i = 0; i < produtos.length; i++) {

                if (produtos[i].categoria == 'Higiene') {
                    alert(`Alimentos
                Nome: ${produtos[i].nome}
                Preço: ${produtos[i].preco}
                Categoria: ${produtos[i].categoria}
                Estoque: ${produtos[i].estoque}un`)

                }
            }
            break;
    }


}




function ModoAdmin() {

    let senha = "";

    do {
        senha = prompt("Modo Admin - Digite a senha:");
    } while (senha != "1234");

    produtos = [];

    alert("Lista resetada com sucesso (sem produtos).");

}

function Sair() {

    alert("Saindo… Até mais!");
    console.log("Sistema encerrado");

}