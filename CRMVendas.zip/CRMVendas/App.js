const leads = [

    { nome: "Maria Souza", empresa: "TechPlus", status: "quente", contatoFeito: false },

    { nome: "João Silva", empresa: "LogiTrans", status: "morno", contatoFeito: false },

    { nome: "Ana Lima", empresa: "FarmaBem", status: "frio", contatoFeito: false }

];



let totalContatos = 0;



const resumoLeads = document.getElementById("resumo-leads");

const botoesFiltro = document.querySelectorAll(".btn-filtro");

const cardsLead = document.querySelectorAll(".card-lead");

const botoesContato = document.querySelectorAll(".btn-contato");

const infoContatos = document.getElementById("info-contatos");

const btnResetar = document.getElementById("btn-resetar");



resumoLeads.textContent = leads.length > 0

    ? `Foram carregados ${leads.length} lead(s) do sistema CRM.` 

    :"Nenhum lead encontrado no sistema.";



botoesFiltro.forEach(botao => {

    botao.addEventListener("click", () => {

        const statusFiltro = botao.getAttribute("data-status");



        cardsLead.forEach(card => {

            const statusCard = card.getAttribute("data-status");



            if (statusFiltro === "todos" || statusFiltro === statusCard) {

                card.style.display = "block";

            } else {

                card.style.display = "none";

            }

        });

    });

});



botoesContato.forEach((botao, indice) => {

    botao.addEventListener("click", () => {

        const lead = leads[indice];



        if (!lead.contatoFeito) {

            lead.contatoFeito = true;

            totalContatos++;

        }



        infoContatos.textContent =

            `Contatos realizados: ${totalContatos} lead(s). Último contato: ${lead.nome} (${lead.empresa}).`;

    });

});



btnResetar.addEventListener("click", () => {

    for (let i = 0; i <= leads.length; i++) {

        leads[i].contatoFeito = false;
        
        totalContatos = 0;

        infoContatos.textContent = "Nenhum contato registrado.";
    }

}); 