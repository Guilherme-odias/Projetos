// Simulação de ofertas carregadas do "servidor"
const ofertas = [
    { nome: "Dipirona 500mg", preco: 12.9 },
    { nome: "Vitamina C 1g", preco: 29.9 },
    { nome: "Protetor Solar FPS 50", preco: 59.9 }
];

// Estado do carrinho
let quantidadeItens = 0;
let totalCarrinho = 0;

// Seletores principais
const resumoOfertas = document.getElementById("resumo-ofertas");
const botoesAdicionar = document.querySelectorAll(".btn-adicionar");
const infoCarrinho = document.getElementById("info-carrinho");
const botaoLimpar = document.getElementById("btn-limpar");

if (ofertas.length === 0) {
    resumoOfertas.textContent = "Nenhuma oferta disponível no momento.";
} else {
    resumoOfertas.textContent = `Temos ${ofertas.length} ofertas especiais para você hoje!`;
}

botoesAdicionar.forEach((botao, indice) => {
    botao.addEventListener("click", () => {
        const ofertaSelecionada = ofertas[indice];

        quantidadeItens++;
        totalCarrinho = totalCarrinho + ofertaSelecionada.preco;

        infoCarrinho.textContent = `Você tem ${quantidadeItens} item(ns) no carrinho. Total: R$ ${totalCarrinho.toFixed(2)}`;

    });
});

botaoLimpar.addEventListener("click", () => {
    quantidadeItens = 0;
    totalCarrinho = 0;
    infoCarrinho.textContent = "Nenhum item no carrinho ainda.";

});

// botoesAdicionar.forEach((botao, indice) => {
//     botao.addEventListener("click", () => { 
//         const ofertaSelecionada = ofertas[indice]; 

//         quantidadeItens++; 
//         totalCarrinho = totalCarrinho + ofertaSelecionada.preco;

//         infoCarrinho.textContent = `Você tem ${quantidadeItens} item(ns) no carrinho. Total: R$ ${totalCarrinho.toFixed(2)}`; 
//     }); 
// }); 

// botaoLimpar.addEventListener("click", () => { 
//     quantidadeItens = 0; 
//     totalCarrinho = 0; 
//     infoCarrinho.textContent = "Nenhum item no carrinho ainda."; 
// }); 