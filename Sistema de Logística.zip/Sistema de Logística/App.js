const entregas = [ 

  { id: 1001, cidade: "São Paulo", status: "pendente", prioridade: "alta" }, 

  { id: 1002, cidade: "Campinas", status: "em-andamento", prioridade: "media" }, 

  { id: 1003, cidade: "Santos", status: "concluida", prioridade: "baixa" } 

]; 

  

const filtroStatus = document.getElementById("filtro-status"); 

const cards = document.querySelectorAll(".card-entrega"); 

const resumoEntregas = document.getElementById("resumo-entregas"); 

const infoPrioridade = document.getElementById("info-prioridade"); 

const botoesAvancar = document.querySelectorAll(".btn-avancar"); 

const formRelatorio = document.getElementById("form-relatorio"); 

const btnGerarRelatorio = document.getElementById("btn-gerar-relatorio"); 

  

function atualizarResumo() { 

  const total = entregas.length; 

  const pendentes = entregas.filter(e => e.status === "pendente").length; 

  const emAndamento = entregas.filter(e => e.status === "em-andamento").length; 

  const concluidas = entregas.filter(e => e.status === "concluida").length; 

  

  resumoEntregas.textContent = `Total: ${total} | Pendentes: ${pendentes} | Em andamento: ${emAndamento} | Concluídas: ${concluidas}`; 

} 

  

// function atualizarResumoPrioridade() { 

//   const altas = entregas.filter(e => e.prioridade === "alta").length; 

//   const medias = entregas.filter(e => e.prioridade === "media").length; 

//   const baixas = entregas.filter(e => e.prioridade === "baixa").length; 

  

//   infoPrioridade.textContent = 

//     `Prioridade alta: ${altas} | Média: ${medias} | Baixa: ${baixas}`;
//     atualizarResumo();  

// } 


filtroStatus.addEventListener("change", () => { 

  const statusSelecionado = filtroStatus.value; 

  

  cards.forEach(card => { 

    const statusCard = card.getAttribute("data-status"); 

  

    if (statusSelecionado === "todas" || statusSelecionado == statusCard) { 
      
      card.style.display = "block"; 

    } else { 

      card.style.display = "none"; 

    }   

    atualizarResumo(); 

  }); 

}); 

  

botoesAvancar.forEach((botao, indice) => { 

  botao.addEventListener("click", () => { 

    const entrega = entregas[indice]; 

  

    if (entrega.status === "pendente") { 

      entrega.status = "em-andamento"; 

    } else if (entrega.status === "em-andamento") { 

      entrega.status = "concluida"; 
      

    } else if (entrega.status === "concluida"){

      entrega.status = "pendente";
     
    }



    const card = cards[indice]; 

    const textoStatus = card.querySelector(".status"); 

    textoStatus.textContent = `Status: ${entrega.status}`; 

  

    atualizarResumo(); 

  }); 

}); 

  

formRelatorio.addEventListener("submit", (evento) => { 

  evento.preventDefault(); 

  

  const totalAltas = entregas.filter(e => e.prioridade === "alta").length; 

  const totalEntregas = entregas.length; 

  

  alert(`Relatório rápido: 

  Entregas com prioridade alta: ${totalAltas} 

  Percentual: ${(totalAltas / totalEntregas * 100).toFixed(2)}%`); 


}); 

  

atualizarResumo(); 

atualizarResumoPrioridade(); 