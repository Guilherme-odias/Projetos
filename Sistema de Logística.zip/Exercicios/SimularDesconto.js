const pedidos = [
    { cliene:"Ana", total: 100},
    { cliene:"Bruno", total: 200},
    { cliene:"Carla", total: 80}
]


const pedidosDesconto = pedidos.map(pedido => {
    const pedidosCopia = pedido.total * 0.85;
    return {...pedido, total:pedidosCopia};
});
console.log(pedidosDesconto);