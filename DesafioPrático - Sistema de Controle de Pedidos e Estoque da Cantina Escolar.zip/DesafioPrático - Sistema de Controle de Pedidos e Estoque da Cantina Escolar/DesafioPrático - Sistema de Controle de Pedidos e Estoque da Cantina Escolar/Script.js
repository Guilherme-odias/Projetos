let produtos = [
    { id: 1, nome: "Coxinha", categoria: "Salgado", preco: 7.5, estoque: 20, ativo: true },
    { id: 2, nome: "Pastel", categoria: "Salgado", preco: 8.0, estoque: 15, ativo: true },
    { id: 3, nome: "Suco", categoria: "Bebida", preco: 5.0, estoque: 30, ativo: true },
];

function CadastrarProdutos(){

    const nomeProduto = prompt("Nome do Produto: ");
    if (!nomeProduto) {
        alert('O CAMPO "Nome" NÃO FOI PREENCHIDO! \nInsira pelo menos um Nome!');
        return;
    };

    const precoProduto = prompt("Preço do produto: ");
    if(isNaN(precoProduto)) {
        alert('Insira um número maior do que zero!');
        return;
    };

    const categoriaProduto = prompt("Categoria do produto \n (Salgado, Bebida): ");
    if (!categoriaProduto) {
        alert('O CAMPO "CATEGORIA" NÃO FOI PREENCHIDO! \nInsira pelo menos uma Categoria.');
        return;

    } else if (categoriaProduto != "Salgado" && (categoriaProduto!= "Bebida")){
        alert('Insira uma categoria válida !!!');
        return;
    };

    const estoqueProduto = prompt("Estoque do produto: ");
    if (isNaN(estoqueProduto)) {
        alert('O CAMPO "Estoque" NÃO FOI PREENCHIDO! \nInsira a quantidade do produto do estoque! ');
        return;

    };

    let novoProduto = {
        nome: nomeProduto,
        categoria: categoriaProduto,
        preco: precoProduto,
        estoque: estoqueProduto
    }

    produtos.push(novoProduto);

    alert(` PRODUTOS CADASTRADOS COM SUCESSO! 
        Nome: ${nomeProduto}
        Categoria: ${precoProduto.toFixed(2)}
        Preço: ${categoriaProduto}
        Estoque: ${estoqueProduto}un`)

};

function ListarProdutos(){
    for(let i = 0; i < produtos.length; i++) {
        alert(`
            Nome: ${produtos[i].nome}
            Categoria: ${produtos[i].categoria}
            Preço: ${produtos[i].preco}
            Estoque: ${produtos[i].estoque}
            `);
    }

    if (produtos == null) {
        alert('Lista vazia !!!');
    }
};

function FiltrarPorCategoria(){
    const categoriaEscolhida = prompt("Escolha uma categoria entre as opções a seguir:\n (Salgado, Bebida)");

    switch (categoriaEscolhida) {
        case "Salgado":
        case "salgado":

            for(let i = 0; i < produtos.length; i++) {
                if (produtos[i].categoria == 'Salgado') {
                    alert (`Salgados
                        Nome: ${produtos[i].nome}
                        Categoria: ${produtos[i].categoria}
                        Preço: ${produtos[i].preco.toFixed(2)}
                        Estoque: ${produtos[i].estoque}un`)
                };
            };
        break;

        case "Bebida":
        case "bebida":

            for(let i = 0; i < produtos.length; i++) {
                if (produtos[i].categoria == 'Bebida') {
                    alert (`Bebidas
                        Nome: ${produtos[i].nome}
                        Categoria: ${produtos[i].categoria}
                        Preço: ${produtos[i].preco.toFixed(2)}
                        Estoque: ${produtos[i].estoque}un`)
                };
            };
        break;
    };
}