const pedidos = [
    {cliente: "Ana", total: 150, status:"pago"},
    {cliente: "Bruno", total: 80, status:"pendente"},
    {cliente: "Carla", total: 200, status:"pago"},
    {cliente: "Diego", total: 90, status:"pendente"}
];

const qtdPagos = pedidos.filter(pedido => pedido.status === "pago").length;
const totalPagos = pedidos.filter(pedido => pedido.status === "pago").reduce((soma, vTotal) => {

    return soma + vTotal.total ;

},0)

const percentualPagos = (qtdPagos / pedidos.length * 100);

console.log(qtdPagos);
console.log(totalPagos);