// const carrinho = [
//     {produto: "Dipirona", preco: 12.9},
//     {produto: "Vitamina C", preco: 29.9},
//     {produto: "Protetor Solar", preco: 59.9}
// ];

// const total = carrinho.reduce((soma, item) => {
//     return soma + item.preco;
// },0);

// console.log(total);

// ==========================================================================
// Reduce moderno

// const despesas = [
//     {nome: "Aluguel", pago: false, valor: 2500}, 
//     {nome: "Internet", pago: false, valor: 800},
//     {nome: "Aluguel", pago: false, valor: 1200},

// ]

// const totalPagas2 = despesas.reduce((soma, d) => {
//     return d.pago ? soma + d.valor : soma;
// },0);

// console.log(totalPagas2)

// ==========================================================================
// For tradicional

// const despesas = [
//     {nome: "Aluguel", pago: true, valor: 2500}, 
//     {nome: "Internet", pago: false, valor: 800},
//     {nome: "Aluguel", pago: false, valor: 1200}
// ]

// let totalPagas = 0;
// for (let i = 0; i < despesas.length; i++){
//     const despesa = despesas[i];
//     if (despesa.pago === true){
//         totalPagas = totalPagas + despesa.valor;
//     }
// }
// console.log(totalPagas);

// const vendas = [12, 90, 29.90, 59.90, 8.50];
// const totalVendas = vendas.reduce((soma, valorAtual) => {
//     return soma + valorAtual;
// },0);
// const mediaVendas = vendas.reduce((soma, venda) => {
//     return soma + venda

// },0) / vendas.length;

// console.log(totalVendas);
// console.log(mediaVendas);



// const idade = 20;
// const podeEntrar = idade >= 18 ? "Sim": "Não";
// console.log(podeEntrar);

// const numeros = [1, 2, 3, 4];
// const soma = numeros.reduce(function(acc, valor){
//     return acc + valor;
// },0);

// console.log(soma);