const produtos = [
    {nome: "Dipirona", preco: 12.90, estoque: 5},
    {nome: "Vitamina C", preco: 29.90, estoque: 0},
    {nome: "Shampoo", preco: 15.90, estoque: 12},
    {nome: "Protetor Solar", preco: 59.90, estoque: 3}
]

const qtdEmEstoque = produtos.filter(produto => produto.estoque).length;

const valorEmEstoque = produtos.reduce((calc, vAtual) =>{
    return calc = vAtual.preco * vAtual.estoque;
},0);

const mediaEstoque = valorEmEstoque/qtdEmEstoque

console.log(`Quantidade de produtos em estoque: ${qtdEmEstoque}`);
console.log(`Valor total dos produtos em estoque: R$ ${valorEmEstoque}`);
console.log(`Valor médio dos produtos em estoque: R$ ${mediaEstoque}`);
