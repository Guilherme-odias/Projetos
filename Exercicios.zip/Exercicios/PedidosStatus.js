const pedidos = [
    {cliente: "Ana", total: 150, status: "pago"},
    {cliente: "Bruno", total: 80, status: "pendente"},
    {cliente: "Carla", total: 200, status: "pago"},
    {cliente: "Diego", total: 90, status: "pendente"}
]

const qtdPagos = pedidos.filter(pedido => pedido.status === "pago").length;

const totalPagos = pedidos.filter(pedido => pedido.status === "pago")
.reduce((soma, valor) => {
    return valor.status === "pago" ? soma + valor.total : soma;
},0);

const percentualPagos = (qtdPagos / pedidos.length * 100).toFixed(1);

console.log(`QTD de pedidos pagos: ${qtdPagos}`);
console.log(`Total do valor dos pedidos: ${totalPagos}`);
console.log(`Percentual de pedidos pagos: ${percentualPagos}`)
