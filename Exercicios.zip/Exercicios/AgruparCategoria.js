const produtos = [
    {nome:"Dipirona", categoria:"medicamento", preco: 12.90},
    {nome:"Higiene bucal", categoria:"higiene", preco: 8.50},
    {nome:"Vitamina C", categoria:"medicamento", preco: 29.90},
    {nome:"Shampoo", categoria:"higiene", preco: 15.90},
]

const porCategoriaM = produtos.reduce((soma, vAtual) => {
    
    return vAtual.categoria === "medicamento" ? soma + vAtual.preco : soma
    
},0);

console.log(`medicamento: ${porCategoriaM}`);

const porCategoriaH = produtos.reduce((soma, vAtual) => {
    
    return vAtual.categoria === "higiene" ? soma + vAtual.preco : soma
    
},0);

console.log(`higiene: ${porCategoriaH}`)


