const vendas = [
    {representante: "Ana", valor: 1500 },
    {representante: "Bruno", valor: 800 },
    {representante: "Ana", valor: 2200 },
    {representante: "Carla", valor: 950 },
    {representante: "Bruno", valor: 1200 }
];

const qtdVendasAna = vendas.filter(venda => venda.representante === "Ana").length;
const totalVendidoAna = vendas.reduce((soma, d) => {
    return d.representante === "Ana" ? soma + d.valor : soma;
},0);
console.log(`Ana fez ${qtdVendasAna} vendas, e obteve um total de R$ ${totalVendidoAna} no total`);

const qtdVendasBruno = vendas.filter(venda => venda.representante === "Bruno").length;
const totalVendidoBruno = vendas.reduce((soma, d) => {
    return d.representante === "Bruno" ? soma + d.valor : soma;
},0);
console.log(`Bruno fez ${qtdVendasBruno} vendas, e obteve um total de R$ ${totalVendidoBruno} no total`);

const qtdVendasCarla = vendas.filter(venda => venda.representante === "Carla").length;
const totalVendidoCarla = vendas.reduce((soma, d) => {
    return d.representante === "Carla" ? soma + d.valor : soma;
},0);
console.log(`Carla fez ${qtdVendasCarla} vendas, e obteve um total de R$ ${totalVendidoCarla} no total`);
