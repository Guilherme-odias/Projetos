const alunos = [
    {nome: "Ana", nota: 8.5, frequencia: 95},
    {nome: "Bruno", nota: 6.0, frequencia: 85},
    {nome: "Carla", nota: 9.0, frequencia: 98}, 
    {nome: "Diego", nota: 7.5, frequencia: 75}
];

const AlunosFrequentes = alunos.filter(aluno => aluno.frequencia > 80).length;

const MediaNotas = alunos.filter(aluno => aluno.frequencia > 80)
.reduce((calc ,vAtual) => calc + (vAtual.nota / AlunosFrequentes),0);

const PercentualAlunosFreq = (AlunosFrequentes  * 100) / alunos.length;

console.log(`Alunos com frequência maior que 80%: `);
console.log(AlunosFrequentes);

console.log(`\nMédia das notas dos alunos frequentes: ${MediaNotas}`);
console.log(`\nPercentual de alunos frequentes: ${PercentualAlunosFreq}%`);
