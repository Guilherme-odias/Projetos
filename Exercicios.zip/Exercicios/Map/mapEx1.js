const clientes = [
    {nome: "ana", sobrenome: "silva"},
    {nome: "bruno", sobrenome: "santos"},
    {nome: "carla", sobrenome: "oliveira"},
    {nome: "diego", sobrenome: "ferreira"},
];

const clientesFormatados = clientes.map(cliente => 
    
    `${cliente.nome.toUpperCase()} ${cliente.sobrenome.toUpperCase()}`);

console.log(clientesFormatados);    